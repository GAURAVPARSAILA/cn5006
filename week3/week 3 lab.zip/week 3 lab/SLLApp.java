import java.util.InputMismatchException;
import java.util.Scanner;


public class SLLApp {

    // Node for Singly Linked List
    static class Node {
        int data;
        Node next;
        Node(int d) { this.data = d; }
    }

    // Custom Singly Linked List implementation
    static class SinglyLinkedList {
        private Node head;
        private int size;

        // Append an element at the tail
        public void addLast(int value) {
            Node n = new Node(value);
            if (head == null) {
                head = n;
            } else {
                Node curr = head;
                while (curr.next != null) curr = curr.next;
                curr.next = n;
            }
            size++;
        }

        //  Print all elements
        public void PrintMe() {
            if (head == null) {
                System.out.println("List is empty.");
                return;
            }
            Node curr = head;
            StringBuilder sb = new StringBuilder();
            while (curr != null) {
                sb.append(curr.data).append(" -> ");
                curr = curr.next;
            }
            sb.append("null");
            System.out.println(sb);
        }

        //  Print element at index (0-based)
        public void printAtIndex(int index) {
            if (index < 0 || index >= size) {
                System.out.println("Invalid index. Valid range: 0 to " + (size - 1));
                return;
            }
            Node curr = head;
            for (int i = 0; i < index; i++) curr = curr.next;
            System.out.println("Element at index " + index + " = " + curr.data);
        }

        // Delete from head or tail
        public void deleteOne(boolean deleteFromHead) {
            if (head == null) {
                System.out.println("Cannot delete. List is empty.");
                return;
            }
            if (deleteFromHead) {
                deleteHead();
            } else {
                deleteTail();
            }
        }

        private void deleteHead() {
            System.out.println("Deleting from head: " + head.data);
            head = head.next;
            size--;
        }

        private void deleteTail() {
            if (head.next == null) {
                System.out.println("Deleting only element (tail=head): " + head.data);
                head = null;
                size = 0;
                return;
            }
            Node prev = null;
            Node curr = head;
            while (curr.next != null) {
                prev = curr;
                curr = curr.next;
            }
            System.out.println("Deleting from tail: " + curr.data);
            prev.next = null;
            size--;
        }

        public int size() { return size; }
        public boolean isEmpty() { return size == 0; }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SinglyLinkedList list = new SinglyLinkedList();

        System.out.println("=== Singly Linked List (SLL) Program ===");
        //  User-driven initialization
        int n = readInt(sc, "How many elements do you want to add to the linked list? ");
        for (int i = 0; i < n; i++) {
            int val = readInt(sc, "Enter value for element " + i + ": ");
            list.addLast(val);
        }

        // Show the initial list
        System.out.println("\nInitial List:");
        list.PrintMe();

        // Simple menu loop for remaining operations
        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1) Print all elements (PrintMe)");
            System.out.println("2) Print element at index");
            System.out.println("3) Delete one element (head or tail)");
            System.out.println("4) Exit");
            int choice = readInt(sc, "Enter choice (1-4): ");

            switch (choice) {
                case 1:
                    list.PrintMe();
                    break;

                case 2:
                    if (list.isEmpty()) {
                        System.out.println("List is empty. Nothing to print.");
                        break;
                    }
                    int idx = readInt(sc, "Enter index (0-based): ");
                    list.printAtIndex(idx);
                    break;

                case 3:
                    if (list.isEmpty()) {
                        System.out.println("List is empty. Nothing to delete.");
                        break;
                    }
                    System.out.print("Delete from (H)ead or (T)ail? ");
                    String ht = sc.next().trim().toLowerCase();
                    if (ht.startsWith("h")) {
                        list.deleteOne(true);
                    } else if (ht.startsWith("t")) {
                        list.deleteOne(false);
                    } else {
                        System.out.println("Invalid choice. Type 'H' or 'T'.");
                    }
                    System.out.println("Current list:");
                    list.PrintMe();
                    break;

                case 4:
                    System.out.println("Exiting. Goodbye!");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid menu option.");
            }
        }
    }

    // Safe integer input helper
    private static int readInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return sc.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid integer.");
                sc.next();
            }
        }
    }
}
